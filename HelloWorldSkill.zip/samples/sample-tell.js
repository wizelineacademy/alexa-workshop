// Sample Tell Output

// Using Response
this.emit(':tell', 'Hello World!');

// Using Response Builder
this.response.speak('Hello World!');
this.emit(':responseReady');


